export const searchActionType = {
    SEARCH_MOBILE_TOGGLE : "SEARCH_MOBILE_TOGGLE ",
    SEARCH_TOGGLE : "SEARCH_TOGGLE "
}