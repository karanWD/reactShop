export const brandActionType = {
    FETCH_BRAND_LIST:"FETCH_BRAND_LIST"
}