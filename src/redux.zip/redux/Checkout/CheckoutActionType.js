export const checkoutActionType = {
    OPEN_ACCORDION :"OPEN_ACCORDION"
}