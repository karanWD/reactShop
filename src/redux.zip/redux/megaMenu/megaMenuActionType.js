export const megaMenuActionType = {
    FETCH_MEGA : "FETCH_MEGA"
}