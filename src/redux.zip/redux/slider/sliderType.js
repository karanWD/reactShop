export const sliderType ={
    FETCH_SLIDER:"FETCH_SLIDER"
}