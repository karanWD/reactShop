export const carouselTypes = {
    CAROUSEL_FETCH:"CAROUSEL_FETCH"
}