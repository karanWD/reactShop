export const selectCarousel = state =>{
     // console.log(state.carousel.carouselItem)
     return state.carousel.carouselItem
}
