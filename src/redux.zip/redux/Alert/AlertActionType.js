export const alertActionType = {
    FETCH_ALERT:"FETCH_ALERT"
}