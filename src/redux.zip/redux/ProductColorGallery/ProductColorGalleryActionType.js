export const productColorGalleryActionType = {
    FETCH_PRODUCT_COLOR_GALLERY:"FETCH_PRODUCT_COLOR_GALLERY"
}