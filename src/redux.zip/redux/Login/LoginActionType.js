export const LoginActionType = {
    OPEN_LOGIN : "OPEN_LOGIN",
    OPEN_CODE_VERIFIED : "OPEN_CODE_VERIFIED",
}