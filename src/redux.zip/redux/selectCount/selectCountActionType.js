export const selectCountActionType = {
    SELECT_COUNT:"SELECT_COUNT"
}