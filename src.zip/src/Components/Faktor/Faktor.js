import React from "react"
import BackIcon from "../ChevronLeft/ChevronLeft";

const Faktor = ()=>{
    return(
        <div className="title ">
            <h1 className="rtl">3. فاکتور خرید </h1>
            <BackIcon/>
        </div>
    )
}

export default Faktor