import React from "react"
import "./Payment.scss"
import BackIcon from "../ChevronLeft/ChevronLeft";


const Payment = ()=>{
    return(
        <div className="payment-container">
            <div className="title">
                <h1 className="rtl">2. طریقه پرداخت  </h1>
                <BackIcon/>
            </div>
            <div className="text-right mt-4">
                <p className="mr-3">طریقه پرداخت خود را انتخاب کنید </p>
                <ul className="d-flex flex-row-reverse ">
                    <li>پرداخت آنلاین</li>
                    <li>پرداخت حضوری</li>
                </ul>
            </div>
        </div>
    )
}

export default Payment