import React from "react"
import "./Checkout.scss"
import Delivery from "../Components/Delivery/Delivery";
import Payment from "../Components/Payment/Payment";
import Faktor from "../Components/Faktor/Faktor";
import Cart from "../Components/Cart/Cart";
import CartItem from "../Components/CartItem/CartItem";

const Checkout = () => {
    return(
        <section className="checkout d-flex flex-row-reverse mt-5 pt-lg-5 px-lg-5">
            <div className="col-lg-6">
              <Delivery/>
              <br/>
              <Payment/>
              <br/>
              <Faktor/>
            </div>
            <div className="col-lg-6">

            </div>
        </section>
    )
}

export default Checkout