export const LoadingAtionType = {
    LOADING : "LOADING"
}