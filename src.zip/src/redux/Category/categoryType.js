export const categoryType ={
    FETCH_CATEGORY:"FETCH_CATEGORY"
}