export const productSliderType ={
    FETCH_PRODUCT_SLIDER:"FETCH_PRODUCT_SLIDER"
}