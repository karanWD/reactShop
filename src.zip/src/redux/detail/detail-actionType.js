export const detailActionType = {
    FETCH_DETAIL : "FETCH_DETAIL",
}