export const productsActionType = {
    FETCH_PRODUCTS : "FETCH_PRODUCTS"
}
