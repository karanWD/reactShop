export const breadcrumbActionType = {
    FETCH_BREADCRUMB:"FETCH_BREADCRUMB"
}